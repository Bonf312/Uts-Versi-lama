
const int SENSOR_PIN = A0;

const int LED_HIJAU = 8;
const int LED_KUNING = 9;
const int LED_MERAH = 10;

unsigned long lastTxTime = 0;
const unsigned long txInterval = 200;

void setup() {
  Serial.begin(9600);

  pinMode(LED_HIJAU, OUTPUT);
  pinMode(LED_KUNING, OUTPUT);
  pinMode(LED_MERAH, OUTPUT);

  digitalWrite(LED_HIJAU, LOW);
  digitalWrite(LED_KUNING, LOW);
  digitalWrite(LED_MERAH, LOW);

  delay(100);
  Serial.println("SYSTEM|READY");
}

void loop() {
  unsigned long currentMillis = millis();

  if (currentMillis - lastTxTime >= txInterval) {
    lastTxTime = currentMillis;

    // Membaca nilai ADC
    int adcValue = analogRead(SENSOR_PIN);

    // Menghitung tegangan
    float voltage = adcValue * (5.0 / 1023.0);

    // Menentukan level dan LED indikator
    const char* level;

    if (adcValue <= 340) {
      level = "RENDAH";

      digitalWrite(LED_HIJAU, HIGH);
      digitalWrite(LED_KUNING, LOW);
      digitalWrite(LED_MERAH, LOW);
    }
    else if (adcValue <= 682) {
      level = "SEDANG";

      digitalWrite(LED_HIJAU, LOW);
      digitalWrite(LED_KUNING, HIGH);
      digitalWrite(LED_MERAH, LOW);
    }
    else {
      level = "TINGGI";

      digitalWrite(LED_HIJAU, LOW);
      digitalWrite(LED_KUNING, LOW);
      digitalWrite(LED_MERAH, HIGH);
    }

    // Mengirim data melalui UART
    Serial.print("SENSOR|");
    Serial.print(adcValue);
    Serial.print("|");
    Serial.print(voltage, 2);
    Serial.print("|");
    Serial.println(level);
  }
}
