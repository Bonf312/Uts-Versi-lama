<!-- Footer Page -->
<footer class="bg-dark text-white pt-5 pb-4 mt-auto">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-4">
                <h5 class="fw-bold text-primary mb-3"><i class="bi bi-ticket-detailed-fill"></i> TravelKu</h5>
                <p class="small text-white-50">
                    Platform pemesanan tiket destinasi wisata, event populer, dan transportasi terlengkap dengan harga terbaik dan proses transaksi cepat.
                </p>
            </div>
            <div class="col-md-4">
                <h6 class="fw-bold mb-3">Navigasi Layanan</h6>
                <ul class="list-unstyled small">
                    <li class="mb-2"><a href="index12.php" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right"></i> Wisata & Event Populer</a></li>
                    <li class="mb-2"><a href="transport.php" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right"></i> Tiket Transportasi</a></li>
                    <li class="mb-2"><a href="promo.php" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right"></i> Promo & Diskon</a></li>
                    <li class="mb-2"><a href="etiket.php" class="text-white-50 text-decoration-none"><i class="bi bi-chevron-right"></i> Lihat & Cetak E-Tiket</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <h6 class="fw-bold mb-3">Dukungan Layanan</h6>
                <p class="small text-white-50 mb-1"><i class="bi bi-whatsapp text-success"></i> WhatsApp: 0812-3456-7890</p>
                <p class="small text-white-50 mb-1"><i class="bi bi-envelope text-warning"></i> Email: support@travelku.com</p>
                <p class="small text-white-50"><i class="bi bi-clock"></i> Layanan CS: 24/7 Setiap Hari</p>
            </div>
        </div>
        <hr class="border-secondary my-4">
        <div class="text-center small text-white-50">
            &copy; <?= date('Y'); ?> TravelKu Ticketing System. All rights reserved.
        </div>
    </div>
</footer>

<!-- Bootstrap 5 JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>