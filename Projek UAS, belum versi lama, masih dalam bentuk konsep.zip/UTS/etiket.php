<?php
require_once __DIR__ . '/config/database.php';
include 'header.php';

// Cek apakah ada parameter kode transaksi
if (!isset($_GET['kode'])) {
    header("Location: index12.php");
    exit;
}

$kode_transaksi = mysqli_real_escape_string($conn, $_GET['kode']);

// Query ambil data pesanan beserta relasinya ke event atau transport
$query = "SELECT o.*, 
                 e.nama_event, e.lokasi AS lokasi_event, e.tanggal AS tanggal_event,
                 t.nama_armada, t.jenis, t.asal, t.tujuan, t.waktu_berangkat
          FROM orders o
          LEFT JOIN events e ON o.event_id = e.id
          LEFT JOIN transports t ON o.transport_id = t.id
          WHERE o.kode_transaksi = '$kode_transaksi'";

$result = mysqli_query($conn, $query);
$order  = mysqli_fetch_assoc($result);

if (!$order) {
    echo "<script>alert('E-Tiket tidak ditemukan!'); window.location='index12.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Tiket - <?= $order['kode_transaksi']; ?></title>
    <!-- Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        @media print {
            .no-print {
                display: none !important;
            }
            body {
                background: white !important;
            }
            .card {
                border: 1px solid #ddd !important;
                box-shadow: none !important;
            }
        }
        .ticket-border {
            border-left: 5px solid #0d6efd;
        }
    </style>
</head>
<body class="bg-light">

<div class="container my-5" style="max-width: 750px;">

    <!-- Tombol Navigasi Aksi -->
    <div class="d-flex justify-content-between align-items-center mb-4 no-print">
        <a href="index12.php" class="btn btn-outline-secondary">
            <i class="bi bi-house"></i> Kembali ke Beranda
        </a>
        <button onclick="window.print()" class="btn btn-primary fw-bold">
            <i class="bi bi-printer-fill"></i> Cetak E-Tiket / PDF
        </button>
    </div>

    <!-- Kartu E-Tiket -->
    <div class="card border-0 shadow-lg ticket-border overflow-hidden">
        <div class="card-header bg-primary text-white py-3 d-flex justify-content-between align-items-center">
            <h4 class="fw-bold mb-0"><i class="bi bi-ticket-perforated-fill"></i> E-TICKET OFFICIAL</h4>
            <span class="badge bg-light text-primary fs-6"><?= $order['kode_transaksi']; ?></span>
        </div>

        <div class="card-body p-4">
            
            <!-- Info Status Pembayaran -->
            <div class="alert alert-success d-flex align-items-center mb-4">
                <i class="bi bi-check-circle-fill fs-3 me-3"></i>
                <div>
                    <strong class="d-block">Pembayaran Berhasil!</strong>
                    <small>Tunjukkan E-Tiket ini saat masuk lokasi destinasi atau melakukan check-in keberangkatan.</small>
                </div>
            </div>

            <!-- Detail Produk Tiket -->
            <div class="row g-3 mb-4 p-3 bg-light rounded border">
                <?php if ($order['tipe_tiket'] == 'transport'): ?>
                    <div class="col-md-12 mb-2">
                        <span class="badge bg-secondary"><?= strtoupper($order['jenis']); ?></span>
                        <h4 class="fw-bold text-primary m-0 mt-1"><?= htmlspecialchars($order['nama_armada']); ?></h4>
                    </div>
                    <div class="col-md-6">
                        <small class="text-muted d-block"><i class="bi bi-geo-alt-fill text-danger"></i> Rute Perjalanan</small>
                        <strong><?= htmlspecialchars($order['asal']); ?> &rarr; <?= htmlspecialchars($order['tujuan']); ?></strong>
                    </div>
                    <div class="col-md-6">
                        <small class="text-muted d-block"><i class="bi bi-clock-fill text-primary"></i> Waktu Keberangkatan</small>
                        <strong><?= date('d M Y, H:i', strtotime($order['waktu_berangkat'])); ?> WIB</strong>
                    </div>
                <?php else: ?>
                    <div class="col-md-12 mb-2">
                        <span class="badge bg-info text-dark">WISATA / EVENT</span>
                        <h4 class="fw-bold text-primary m-0 mt-1"><?= htmlspecialchars($order['nama_event']); ?></h4>
                    </div>
                    <div class="col-md-6">
                        <small class="text-muted d-block"><i class="bi bi-geo-alt-fill text-danger"></i> Lokasi Destinasi</small>
                        <strong><?= htmlspecialchars($order['lokasi_event']); ?></strong>
                    </div>
                    <div class="col-md-6">
                        <small class="text-muted d-block"><i class="bi bi-calendar-event-fill text-primary"></i> Tanggal Event</small>
                        <strong><?= !empty($order['tanggal_event']) ? date('d M Y', strtotime($order['tanggal_event'])) : 'Sesuai Jadwal Operasional'; ?></strong>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Detail Pemesan & Transaksi -->
            <div class="row g-3 border-top pt-3">
                <div class="col-md-6">
                    <small class="text-muted d-block">Nama Pemesan</small>
                    <h6 class="fw-bold"><?= htmlspecialchars($order['nama_pemesan']); ?></h6>
                </div>
                <div class="col-md-6">
                    <small class="text-muted d-block">Email & WhatsApp</small>
                    <h6 class="fw-bold"><?= htmlspecialchars($order['email_pemesan']); ?> / <?= htmlspecialchars($order['no_hp']); ?></h6>
                </div>
                <div class="col-md-4">
                    <small class="text-muted d-block">Jumlah Tiket</small>
                    <h6 class="fw-bold"><?= $order['jumlah_tiket']; ?> Tiket</h6>
                </div>
                <div class="col-md-4">
                    <small class="text-muted d-block">Metode Pembayaran</small>
                    <h6 class="fw-bold"><?= htmlspecialchars($order['metode_pembayaran']); ?></h6>
                </div>
                <div class="col-md-4">
                    <small class="text-muted d-block">Total Pembayaran</small>
                    <h6 class="fw-bold text-success">Rp <?= number_format($order['total_bayar'], 0, ',', '.'); ?></h6>
                </div>
            </div>

            <hr class="my-4">

            <!-- QR Code Dummy / Barcode Verifikasi -->
            <div class="text-center py-2">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=<?= $order['kode_transaksi']; ?>" alt="QR Code Tiket" class="img-thumbnail mb-2">
                <p class="small text-muted font-monospace m-0">Kode Verifikasi: <strong><?= $order['kode_transaksi']; ?></strong></p>
            </div>

        </div>

        <div class="card-footer bg-light text-center py-3">
            <small class="text-muted">&copy; <?= date('Y'); ?> TravelKu Ticketing System. Simpan atau cetak tiket ini sebagai bukti sah.</small>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php include 'footer.php'; ?>