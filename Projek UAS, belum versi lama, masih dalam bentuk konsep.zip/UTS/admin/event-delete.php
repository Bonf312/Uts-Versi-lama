<?php
require_once __DIR__ . '/../config/database.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // 1. Ambil nama gambar dulu sebelum data dihapus dari DB
    $query = mysqli_query($conn, "SELECT gambar FROM events WHERE id = $id");
    $data  = mysqli_fetch_assoc($query);

    if ($data) {
        $path_gambar = '../uploads/' . $data['gambar'];
        
        // Hapus file gambar fisik jika ada
        if (file_exists($path_gambar) && !empty($data['gambar'])) {
            unlink($path_gambar);
        }

        // 2. Hapus data dari MySQL
        mysqli_query($conn, "DELETE FROM events WHERE id = $id");
    }
}

header("Location: events.php");
exit;
?>