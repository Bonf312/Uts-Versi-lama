<?php
require_once __DIR__ . '/../config/database.php';

// --- PROSES UBAH STATUS PEMBAYARAN ---
if (isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $status   = mysqli_real_escape_string($conn, $_POST['status']);

    $query = "UPDATE orders SET status = '$status' WHERE id = $order_id";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Status pesanan berhasil diperbarui!'); window.location='orders.php';</script>";
    } else {
        echo "<script>alert('Gagal mengubah status pesanan.');</script>";
    }
}

// --- PROSES HAPUS PESANAN ---
if (isset($_GET['delete'])) {
    $order_id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM orders WHERE id = $order_id");
    header("Location: orders.php");
    exit;
}

// --- AMBIL DATA PESANAN ---
$result = mysqli_query($conn, "SELECT * FROM orders ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pesanan - Admin Panel</title>
    <!-- Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="bg-light">
<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-tags-fill text-danger"></i> Kelola pemesanan </h2>
        <a href="index.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Kembali ke Dashboard </a>
    </div>

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-dark"><i class="bi bi-receipt-cutoff"></i> Daftar Pesanan Tiket Masuk</h2>
    </div>

    <!-- Tabel Data Pemesan -->
    <div class="card shadow-sm border-0">
        <div class="card-header bg-dark text-white">
            <i class="bi bi-people-fill"></i> Data Transaksi & Pemesan
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-secondary">
                        <tr>
                            <th>Kode Transaksi</th>
                            <th>Nama Pemesan</th>
                            <th>Kontak (Email / No HP)</th>
                            <th>Total Bayar</th>
                            <th>Tanggal Pesan</th>
                            <th>Status Pembayaran</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><span class="badge bg-secondary font-monospacefs-6"><?= htmlspecialchars($row['kode_transaksi']); ?></span></td>
                                <td class="fw-bold"><?= htmlspecialchars($row['nama_pemesan']); ?></td>
                                <td>
                                    <small class="d-block text-muted"><i class="bi bi-envelope"></i> <?= htmlspecialchars($row['email_pemesan']); ?></small>
                                    <small class="d-block text-muted"><i class="bi bi-whatsapp"></i> <?= htmlspecialchars($row['no_hp']); ?></small>
                                </td>
                                <td class="text-success fw-bold">Rp <?= number_format($row['total_bayar'], 0, ',', '.'); ?></td>
                                <td><small class="text-muted"><i class="bi bi-clock"></i> <?= date('d M Y, H:i', strtotime($row['created_at'])); ?></small></td>
                                <td>
                                    <!-- Form Ubah Status Langsung di Tabel -->
                                    <form action="" method="POST" class="d-flex align-items-center gap-1">
                                        <input type="hidden" name="order_id" value="<?= $row['id']; ?>">
                                        <select name="status" class="form-select form-select-sm border-<?= $row['status'] == 'lunas' ? 'success' : ($row['status'] == 'pending' ? 'warning' : 'danger'); ?>" style="width: 110px;">
                                            <option value="pending" <?= $row['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="lunas" <?= $row['status'] == 'lunas' ? 'selected' : ''; ?>>Lunas</option>
                                            <option value="batal" <?= $row['status'] == 'batal' ? 'selected' : ''; ?>>Batal</option>
                                        </select>
                                        <button type="submit" name="update_status" class="btn btn-sm btn-outline-primary" title="Simpan Status">
                                            <i class="bi bi-check-lg"></i>
                                        </button>
                                    </form>
                                </td>
                                <td class="text-center">
                                    <a href="orders.php?delete=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus riwayat pesanan ini?')">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">Belum ada transaksi atau pesanan masuk.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap 5 JS Bundle CDN -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>