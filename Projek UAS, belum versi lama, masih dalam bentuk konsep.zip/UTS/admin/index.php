<?php
require_once __DIR__ . '/../config/database.php';

// Hitung total statistik
$total_events     = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM events"));
$total_transports = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM transports"));
$total_promos     = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM promos"));
$total_orders     = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM orders"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - TravelKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="bg-light">

<!-- Navbar Admin -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php"><i class="bi bi-speedometer2"></i> Admin Panel TravelKu</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <li class="nav-item"><a class="nav-link active" href="index.php"><i class="bi bi-house-door"></i> Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="events.php"><i class="bi bi-ticket-perforated"></i> Kelola Wisata/Event</a></li>
                <li class="nav-item"><a class="nav-link" href="transports.php"><i class="bi bi-bus-front-fill"></i> Kelola Transportasi</a></li>
                <li class="nav-item"><a class="nav-link" href="promos.php"><i class="bi bi-tags-fill"></i> Kelola Promo</a></li>
                <li class="nav-item"><a class="nav-link" href="orders.php"><i class="bi bi-cart-check"></i> Pesanan</a></li>
                <li class="nav-item ms-lg-2">
                    <a class="btn btn-outline-light btn-sm" href="../index12.php" target="_self"><i class="bi bi-globe"></i> Lihat Website</a>
                    
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Main Container -->
<div class="container my-5">
    <div class="mb-4">
        <h2 class="fw-bold m-0">Selamat Datang, Admin!</h2>
        <p class="text-muted m-0">Kelola tiket wisata, event, transportasi, promo, dan transaksi dalam satu tempat.</p>
    </div>

    <!-- 4 Stats Cards -->
    <div class="row g-3 mb-5">
        <!-- Card 1: Event/Wisata -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-primary text-white p-3 h-100">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50">Total Wisata & Event</h6>
                        <h2 class="fw-bold mb-0"><?= $total_events; ?></h2>
                    </div>
                    <i class="bi bi-ticket-perforated fs-1 opacity-50"></i>
                </div>
                <a href="events.php" class="text-white text-decoration-none mt-3 d-inline-block small">Kelola Event &rarr;</a>
            </div>
        </div>

        <!-- Card 2: Transportasi -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-success text-white p-3 h-100">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50">Jadwal Transportasi</h6>
                        <h2 class="fw-bold mb-0"><?= $total_transports; ?></h2>
                    </div>
                    <i class="bi bi-bus-front-fill fs-1 opacity-50"></i>
                </div>
                <a href="transports.php" class="text-white text-decoration-none mt-3 d-inline-block small">Kelola Transportasi &rarr;</a>
            </div>
        </div>

        <!-- Card 3: Promo -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-danger text-white p-3 h-100">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-white-50">Total Kode Promo</h6>
                        <h2 class="fw-bold mb-0"><?= $total_promos; ?></h2>
                    </div>
                    <i class="bi bi-tags-fill fs-1 opacity-50"></i>
                </div>
                <a href="promos.php" class="text-white text-decoration-none mt-3 d-inline-block small">Kelola Promo &rarr;</a>
            </div>
        </div>

        <!-- Card 4: Transaksi/Orders -->
        <div class="col-md-3">
            <div class="card border-0 shadow-sm bg-warning text-dark p-3 h-100">
                <div class="d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="text-dark-50">Total Pemesanan</h6>
                        <h2 class="fw-bold mb-0"><?= $total_orders; ?></h2>
                    </div>
                    <i class="bi bi-cart-check fs-1 opacity-50"></i>
                </div>
                <a href="orders.php" class="text-dark text-decoration-none mt-3 d-inline-block small">Lihat Pesanan &rarr;</a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>