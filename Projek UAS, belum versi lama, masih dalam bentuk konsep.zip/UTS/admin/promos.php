<?php
require_once __DIR__ . '/../config/database.php';

// --- PROSES TAMBAH PROMO ---
if (isset($_POST['tambah_promo'])) {
    $kode_promo        = strtoupper(trim(mysqli_real_escape_string($conn, $_POST['kode_promo'])));
    $potongan_harga    = $_POST['potongan_harga'];
    $minimal_transaksi = $_POST['minimal_transaksi'];
    $berlaku_hingga    = $_POST['berlaku_hingga'];

    $query = "INSERT INTO promos (kode_promo, potongan_harga, minimal_transaksi, berlaku_hingga) 
              VALUES ('$kode_promo', '$potongan_harga', '$minimal_transaksi', '$berlaku_hingga')";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Promo berhasil ditambahkan!'); window.location='promos.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan promo!');</script>";
    }
}

// Ambil semua data promo
$promos = mysqli_query($conn, "SELECT * FROM promos ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Promo - Admin TravelKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="bg-light">

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-tags-fill text-danger"></i> Kelola Kode Promo & Diskon</h2>
        <a href="index.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Kembali ke Dashboard</a>
    </div>

    <!-- Form Tambah Promo -->
    <div class="card border-0 shadow-sm p-4 mb-5">
        <h5 class="fw-bold mb-3"><i class="bi bi-plus-circle"></i> Tambah Kode Promo Baru</h5>
        <form action="" method="POST">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label fw-bold">Kode Promo</label>
                    <input type="text" name="kode_promo" class="form-control text-uppercase" placeholder="Contoh: HEMAT50" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Potongan Harga (Rp)</label>
                    <input type="number" name="potongan_harga" class="form-control" placeholder="50000" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Minimal Transaksi (Rp)</label>
                    <input type="number" name="minimal_transaksi" class="form-control" placeholder="100000" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Berlaku Sampai Tanggal</label>
                    <input type="date" name="berlaku_hingga" class="form-control" required>
                </div>
                <div class="col-12">
                    <button type="submit" name="tambah_promo" class="btn btn-danger font-weight-bold">
                        <i class="bi bi-save"></i> Simpan Promo
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Tabel Daftar Promo -->
    <div class="card border-0 shadow-sm p-4">
        <h5 class="fw-bold mb-3">Daftar Promo Aktif</h5>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Kode Promo</th>
                        <th>Potongan Harga</th>
                        <th>Min. Transaksi</th>
                        <th>Masa Berlaku</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($promos) > 0): ?>
                        <?php $no = 1; $today = date('Y-m-d'); while ($p = mysqli_fetch_assoc($promos)): ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><span class="badge bg-danger fs-6 font-monospace"><?= $p['kode_promo']; ?></span></td>
                            <td class="fw-bold text-success">Rp <?= number_format($p['potongan_harga'], 0, ',', '.'); ?></td>
                            <td>Rp <?= number_format($p['minimal_transaksi'], 0, ',', '.'); ?></td>
                            <td><i class="bi bi-calendar"></i> <?= date('d M Y', strtotime($p['berlaku_hingga'])); ?></td>
                            <td>
                                <?php if ($p['berlaku_hingga'] >= $today): ?>
                                    <span class="badge bg-success">Aktif</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Kadaluarsa</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="promo-delete.php?id=<?= $p['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus promo ini?')">
                                    <i class="bi bi-trash"></i> Hapus
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center py-4 text-muted">Belum ada kode promo.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>