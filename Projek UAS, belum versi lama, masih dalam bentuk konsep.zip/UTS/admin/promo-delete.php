<?php
require_once __DIR__ . '/../config/database.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    mysqli_query($conn, "DELETE FROM promos WHERE id = $id");
}

header("Location: promos.php");
exit;
?>