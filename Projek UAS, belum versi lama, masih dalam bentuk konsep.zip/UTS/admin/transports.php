<?php
require_once __DIR__ . '/../config/database.php';

// --- PROSES TAMBAH JADWAL TRANSPORTASI ---
if (isset($_POST['tambah_transport'])) {
    $jenis           = $_POST['jenis'];
    $nama_armada     = mysqli_real_escape_string($conn, $_POST['nama_armada']);
    $asal            = mysqli_real_escape_string($conn, $_POST['asal']);
    $tujuan          = mysqli_real_escape_string($conn, $_POST['tujuan']);
    $waktu_berangkat = $_POST['waktu_berangkat'];
    $harga           = $_POST['harga'];
    $stok_kursi      = $_POST['stok_kursi'];

    $query = "INSERT INTO transports (jenis, nama_armada, asal, tujuan, waktu_berangkat, harga, stok_kursi) 
              VALUES ('$jenis', '$nama_armada', '$asal', '$tujuan', '$waktu_berangkat', '$harga', '$stok_kursi')";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Jadwal transportasi berhasil ditambahkan!'); window.location='transports.php';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan data.');</script>";
    }
}

// --- PROSES HAPUS ---
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    mysqli_query($conn, "DELETE FROM transports WHERE id = $id");
    header("Location: transports.php");
    exit;
}

// Ambil Data Transportasi
$result = mysqli_query($conn, "SELECT * FROM transports ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Transportasi - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="bg-light">

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-primary"><i class="bi bi-bus-front-fill"></i> Kelola Tiket Transportasi</h2>
        <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Kembali ke Dashboard</a>
    </div>

    <!-- Form Tambah Transportasi -->
    <div class="card shadow-sm border-0 mb-5">
        <div class="card-header bg-primary text-white font-weight-bold">
            <i class="bi bi-plus-circle"></i> Tambah Jadwal Armada Baru
        </div>
        <div class="card-body">
            <form action="" method="POST">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">Jenis Transportasi</label>
                        <select name="jenis" class="form-select" required>
                            <option value="pesawat">Pesawat</option>
                            <option value="kereta">Kereta Api</option>
                            <option value="bus">Bus / Travel</option>
                        </select>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label">Nama Armada / Maskapai</label>
                        <input type="text" name="nama_armada" class="form-control" placeholder="Contoh: Garuda Indonesia / Argo Parahyangan" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Kota Asal (Keberangkatan)</label>
                        <input type="text" name="asal" class="form-control" placeholder="Contoh: Jakarta (CGK)" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Kota Tujuan</label>
                        <input type="text" name="tujuan" class="form-control" placeholder="Contoh: Bali (DPS)" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Waktu Berangkat</label>
                        <input type="datetime-local" name="waktu_berangkat" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Harga Tiket (Rp)</label>
                        <input type="number" name="harga" class="form-control" placeholder="750000" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Kapasitas Kursi</label>
                        <input type="number" name="stok_kursi" class="form-control" placeholder="50" required>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="tambah_transport" class="btn btn-primary w-100">
                            <i class="bi bi-save"></i> Simpan Jadwal Transportasi
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel Daftar Transportasi -->
    <div class="card shadow-sm border-0">
        <div class="card-header bg-dark text-white">
            <i class="bi bi-card-list"></i> Daftar Rute & Jadwal Aktif
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-secondary">
                        <tr>
                            <th>Jenis</th>
                            <th>Armada</th>
                            <th>Rute (Asal &rarr; Tujuan)</th>
                            <th>Waktu Berangkat</th>
                            <th>Harga</th>
                            <th>Sisa Kursi</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($result) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-<?= $row['jenis'] == 'pesawat' ? 'primary' : ($row['jenis'] == 'kereta' ? 'warning text-dark' : 'success'); ?>">
                                        <?= ucfirst($row['jenis']); ?>
                                    </span>
                                </td>
                                <td class="fw-bold"><?= htmlspecialchars($row['nama_armada']); ?></td>
                                <td><?= htmlspecialchars($row['asal']); ?> &rarr; <?= htmlspecialchars($row['tujuan']); ?></td>
                                <td><small class="text-muted"><i class="bi bi-clock"></i> <?= date('d M Y, H:i', strtotime($row['waktu_berangkat'])); ?></small></td>
                                <td class="text-success fw-bold">Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                                <td><?= $row['stok_kursi']; ?> kursi</td>
                                <td class="text-center">
                                    <a href="transports.php?delete=<?= $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus rute ini?')">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">Belum ada jadwal transportasi.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>