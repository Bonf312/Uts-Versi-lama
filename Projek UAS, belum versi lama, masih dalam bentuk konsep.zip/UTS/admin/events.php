<?php
require_once __DIR__ . '/../config/database.php';

// --- PROSES TAMBAH EVENT ---
if (isset($_POST['tambah'])) {
    $nama_event = mysqli_real_escape_string($conn, $_POST['nama_event']);
    $kategori   = mysqli_real_escape_string($conn, $_POST['kategori']);
    $lokasi     = mysqli_real_escape_string($conn, $_POST['lokasi']);
    $tanggal    = $_POST['tanggal'];
    $harga      = $_POST['harga'];
    $stok       = $_POST['stok'];
    $deskripsi  = mysqli_real_escape_string($conn, $_POST['deskripsi']);

    // Proses Upload Gambar
    $gambar     = $_FILES['gambar']['name'];
    $tmp_name   = $_FILES['gambar']['tmp_name'];
    $new_gambar = time() . '_' . $gambar;

    if (!empty($gambar)) {
        move_uploaded_file($tmp_name, "../uploads/" . $new_gambar);
    } else {
        $new_gambar = '';
    }

    $query = "INSERT INTO events (nama_event, kategori, lokasi, tanggal, harga, stok, deskripsi, gambar) 
              VALUES ('$nama_event', '$kategori', '$lokasi', '$tanggal', '$harga', '$stok', '$deskripsi', '$new_gambar')";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Event berhasil ditambahkan!'); window.location='events.php';</script>";
    } else {
        echo "<script>alert('Gagal menambah event!');</script>";
    }
}

// --- PROSES HAPUS EVENT ---
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM events WHERE id = $id");
    header("Location: events.php");
    exit;
}

// Ambil semua data event
$events = mysqli_query($conn, "SELECT * FROM events ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Event & Wisata - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body class="bg-light">

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2><i class="bi bi-ticket-perforated"></i> Kelola Event & Wisata</h2>
        <a href="index.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Kembali ke Dashboard</a>
    </div>

    <!-- Form Tambah Event -->
    <div class="card border-0 shadow-sm p-4 mb-5">
        <h5 class="fw-bold mb-3">Tambah Event / Wisata Baru</h5>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Nama Event / Wisata</label>
                    <input type="text" name="nama_event" class="form-control" required placeholder="Contoh: Tiket Candi Borobudur">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Kategori</label>
                    <select name="kategori" class="form-select" required>
                        <option value="wisata">Wisata</option>
                        <option value="event">Event</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Tanggal Pelaksanaan</label>
                    <input type="date" name="tanggal" class="form-control" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Lokasi</label>
                    <input type="text" name="lokasi" class="form-control" required placeholder="Kab. Magelang, Jawa Tengah">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Harga Tiket (Rp)</label>
                    <input type="number" name="harga" class="form-control" required placeholder="50000">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Stok Tiket</label>
                    <input type="number" name="stok" class="form-control" required placeholder="100">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Upload Gambar / Banner</label>
                    <input type="file" name="gambar" class="form-control" accept="image/*">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Deskripsi Singkat</label>
                    <textarea name="deskripsi" class="form-control" rows="1" placeholder="Keterangan singkat produk..."></textarea>
                </div>
            </div>
            <button type="submit" name="tambah" class="btn btn-primary mt-3 fw-bold">
                <i class="bi bi-plus-lg"></i> Simpan Event
            </button>
        </form>
    </div>

    <!-- Tabel Daftar Event -->
    <div class="card border-0 shadow-sm p-4">
        <h5 class="fw-bold mb-3">Daftar Event / Wisata</h5>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Gambar</th>
                        <th>Nama Event</th>
                        <th>Kategori</th>
                        <th>Tanggal</th>
                        <th>Lokasi</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; while ($row = mysqli_fetch_assoc($events)): ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td>
                            <?php if ($row['gambar']): ?>
                                <img src="../uploads/<?= $row['gambar']; ?>" width="60" class="rounded">
                            <?php else: ?>
                                <span class="badge bg-secondary">No Image</span>
                            <?php endif; ?>
                        </td>
                        <td class="fw-bold"><?= htmlspecialchars($row['nama_event']); ?></td>
                        <td><span class="badge bg-info text-dark"><?= ucfirst($row['kategori']); ?></span></td>
                        <td><?= !empty($row['tanggal']) ? date('d M Y', strtotime($row['tanggal'])) : '-'; ?></td>
                        <td><?= htmlspecialchars($row['lokasi']); ?></td>
                        <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                        <td><?= $row['stok']; ?></td>
                        <td>
                            <a href="events.php?hapus=<?= $row['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus event ini?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>