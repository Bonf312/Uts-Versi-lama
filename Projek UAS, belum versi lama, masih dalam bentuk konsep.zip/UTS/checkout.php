<?php
require_once __DIR__ . '/config/database.php';
include 'header.php';

$id   = isset($_GET['id']) ? intval($_GET['id']) : 0;
$type = isset($_GET['type']) ?$_GET['type'] : 'event';

$item = null;
$nama_item = '';$harga = 0;

if ($type === 'transport') {
    $q = mysqli_query($conn, "SELECT * FROM transports WHERE id = $id");
    if ($q && mysqli_num_rows($q) > 0) {
        $item = mysqli_fetch_assoc($q);
        $nama_item =$item['nama_armada'] . ' (' . $item['asal'] . ' - ' .$item['tujuan'] . ')';
        $harga =$item['harga'];
    }
} else {
    $q = mysqli_query($conn, "SELECT * FROM events WHERE id = $id");
    if ($q && mysqli_num_rows($q) > 0) {
        $item = mysqli_fetch_assoc($q);
        $nama_item =$item['nama_event'];
        $harga =$item['harga'];
    }
}

// Proses submit form checkout
if (isset($_POST['proses_checkout'])) {
    $nama_pemesan  = mysqli_real_escape_string($conn, $_POST['nama_pemesan']);$email_pemesan = mysqli_real_escape_string($conn,$_POST['email_pemesan']);
    $no_hp         = mysqli_real_escape_string($conn, $_POST['no_hp']);$jumlah_tiket  = max(1, intval($_POST['jumlah_tiket']));$kode_promo    = strtoupper(trim(mysqli_real_escape_string($conn,$_POST['kode_promo'])));

    $kode_transaksi = 'TRX-' . date('Ymd') . '-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 5));
    $subtotal = $harga * $jumlah_tiket;
    $potongan = 0;

    if (!empty($kode_promo)) {$today = date('Y-m-d');
        $q_promo = mysqli_query($conn, "SELECT * FROM promos WHERE kode_promo = '$kode_promo' AND berlaku_hingga >= '$today'");
        if ($q_promo && mysqli_num_rows($q_promo) > 0) {
            $p = mysqli_fetch_assoc($q_promo);
            if ($subtotal >=$p['minimal_transaksi']) {
                $potongan =$p['potongan_harga'];
            }
        }
    }

    $total_bayar = max(0, $subtotal -$potongan);
    
    // Tentukan ID mana yang diisi berdasarkan tipe (event / transport)
    $event_id = ($type === 'event') ?$id : "NULL";
    $transport_id = ($type === 'transport') ?$id : "NULL";
    
    // Default metode pembayaran (karena tidak ada di form)
    $metode_pembayaran = "Transfer Bank";

    // PERBAIKAN: Insert ke tabel `orders`, dan tambahkan kolom relasinya
    $query = "INSERT INTO orders (kode_transaksi, event_id, transport_id, tipe_tiket, nama_pemesan, email_pemesan, no_hp, jumlah_tiket, metode_pembayaran, total_bayar, status) 
              VALUES ('$kode_transaksi',$event_id, $transport_id, '$type', '$nama_pemesan', '$email_pemesan', '$no_hp',$jumlah_tiket, '$metode_pembayaran', '$total_bayar', 'lunas')";

    if (mysqli_query($conn,$query)) {
        // PERBAIKAN: Arahkan ke etiket.php dengan parameter 'kode'
        echo "<script>
                alert('Pemesanan Berhasil!');
                window.location='etiket.php?kode=$kode_transaksi';
              </script>";
        exit;
    } else {
        $error_msg = "Gagal memproses transaksi: " . mysqli_error($conn);
    }
}
?>

<!-- HTML Form di bawahnya tetap sama... -->

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 shadow-sm p-4">
                <h3 class="fw-bold mb-4 text-primary"><i class="bi bi-cart-check"></i> Form Checkout Tiket</h3>

                <?php if (isset($error_msg)): ?>
                    <div class="alert alert-danger"><?= $error_msg; ?></div>
                <?php endif; ?>

                <?php if ($item): ?>
                    <!-- Detail Pesanan -->
                    <div class="alert alert-light border d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <span class="badge bg-primary mb-1"><?= strtoupper($type); ?></span>
                            <h5 class="fw-bold mb-0 text-dark"><?= htmlspecialchars($nama_item); ?></h5>
                        </div>
                        <div class="text-end">
                            <small class="text-muted d-block">Harga Satuan</small>
                            <strong class="fs-5 text-primary">Rp <?= number_format($harga, 0, ',', '.'); ?></strong>
                        </div>
                    </div>

                    <!-- Form Pemesan -->
                    <form action="" method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nama Pemesan</label>
                            <input type="text" name="nama_pemesan" class="form-control" required placeholder="Nama lengkap sesuai KTP">
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Email Pemesan</label>
                                <input type="email" name="email_pemesan" class="form-control" required placeholder="nama@email.com">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Nomor HP / WhatsApp</label>
                                <input type="text" name="no_hp" class="form-control" required placeholder="08123456789">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Jumlah Tiket</label>
                                <input type="number" name="jumlah_tiket" class="form-control" value="1" min="1" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-semibold">Kode Promo (Opsional)</label>
                                <input type="text" name="kode_promo" class="form-control text-uppercase" placeholder="Masukkan kode promo">
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                            <a href="index12.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Kembali</a>
                            <button type="submit" name="proses_checkout" class="btn btn-primary btn-lg fw-bold">
                                <i class="bi bi-credit-card"></i> Bayar Sekarang
                            </button>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-exclamation-triangle fs-1 text-warning d-block mb-3"></i>
                        <h5>Item tidak ditemukan atau tautan salah.</h5>
                        <a href="index12.php" class="btn btn-primary mt-3">Kembali ke Beranda</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>