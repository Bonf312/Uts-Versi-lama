<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelKu - Tiket Wisata, Event & Transportasi Online</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        .hero-banner {
            background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
            color: white;
            padding: 60px 0;
        }
        .card-hover {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1) !important;
        }
    </style>
</head>
<body class="bg-light d-flex flex-column min-vh-100">

<!-- Header / Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary sticky-top shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold fs-4" href="index12.php">
            <i class="bi bi-ticket-detailed-fill"></i> TravelKu
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'index12.php' || $current_page == 'index.php') ? 'active fw-bold' : ''; ?>" href="index12.php">
                        <i class="bi bi-compass"></i> Wisata & Event
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'transport.php') ? 'active fw-bold' : ''; ?>" href="transport.php">
                        <i class="bi bi-bus-front-fill"></i> Transportasi
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= ($current_page == 'promo.php') ? 'active fw-bold' : ''; ?>" href="promo.php">
                        <i class="bi bi-tags-fill"></i> Promo Spesial
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (strpos($current_page, 'tiket') !== false || strpos($current_page, 'etiket') !== false) ? 'active fw-bold' : ''; ?>" href="etiket.php">
                        <i class="bi bi-receipt"></i> Cek E-Tiket
                    </a>
                </li>
            </ul>
            <div class="d-flex align-items-center">
                <a href="admin/index.php" class="btn btn-outline-light btn-sm fw-semibold">
                    <i class="bi bi-person-lock"></i> Panel Admin
                </a>
            </div>
        </div>
    </div>
</nav>