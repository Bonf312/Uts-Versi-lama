<?php
require_once __DIR__ . '/config/database.php';
include 'header.php';

$today  = date('Y-m-d');
$promos = mysqli_query($conn, "SELECT * FROM promos WHERE berlaku_hingga >= '$today' ORDER BY id DESC");
?>

<div class="hero-banner text-center mb-5 bg-danger">
    <div class="container">
        <h1 class="fw-bold display-5"><i class="bi bi-tags-fill"></i> Kode Promo & Diskon Spesial</h1>
        <p class="lead opacity-75">Gunakan kode promo saat checkout untuk mendapatkan harga jauh lebih hemat</p>
    </div>
</div>

<div class="container mb-5">
    <div class="row g-4">
        <?php if (mysqli_num_rows($promos) > 0): ?>
            <?php while ($p = mysqli_fetch_assoc($promos)): ?>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm bg-danger text-white h-100 card-hover">
                    <div class="card-body p-4 d-flex flex-column justify-content-between">
                        <div>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="badge bg-light text-danger fs-6 font-monospace px-3 py-2"><?= $p['kode_promo']; ?></span>
                                <small><i class="bi bi-clock"></i> s/d <?= date('d M Y', strtotime($p['berlaku_hingga'])); ?></small>
                            </div>
                            <h4 class="fw-bold mb-2">Diskon Rp <?= number_format($p['potongan_harga'], 0, ',', '.'); ?></h4>
                            <p class="small opacity-75">Min. Pembelian Rp <?= number_format($p['minimal_transaksi'], 0, ',', '.'); ?></p>
                        </div>
                        <div class="mt-3">
                            <button onclick="navigator.clipboard.writeText('<?= $p['kode_promo']; ?>'); alert('Kode promo disalin: <?= $p['kode_promo']; ?>');" class="btn btn-light text-danger w-100 fw-bold">
                                <i class="bi bi-copy"></i> Salin Kode Promo
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted fs-5">Belum ada promo aktif saat ini.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>