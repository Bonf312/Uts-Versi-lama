<?php
$host     = "localhost";
$username = "root";
$password = "";
$database = "db_tiketing1"; // Sesuaikan dengan nama database baru

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>