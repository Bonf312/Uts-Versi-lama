<?php
require_once __DIR__ . '/config/database.php';
include 'header.php';

// Ambil data event & wisata
$events = mysqli_query($conn, "SELECT * FROM events ORDER BY id DESC");
?>

<style>
    /* Custom Styles untuk Halaman Utama */
    .hero-section {
        background-image: url('https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?auto=format&fit=crop&q=80&w=1920'); /* Gambar dari Unsplash */
        background-size: cover;
        background-position: center;
        position: relative;
        height: 60vh;
        min-height: 400px;
        display: flex;
        align-items: center;
    }
    .hero-overlay {
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background: linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.7));
    }
    .feature-icon-box {
        width: 70px;
        height: 70px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background-color: #e7f1ff;
        color: #0d6efd;
        margin: 0 auto;
    }
    .modern-card {
        border-radius: 1rem;
        transition: all 0.3s ease;
    }
    .modern-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.1) !important;
    }
    .modern-card img {
        border-top-left-radius: 1rem;
        border-top-right-radius: 1rem;
    }
    .cta-section {
        background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
        border-radius: 1.5rem;
    }
</style>

<!-- Hero Section -->
<div class="hero-section text-center text-white mb-5">
    <div class="hero-overlay"></div>
    <div class="container position-relative z-1">
        <h1 class="display-4 fw-bolder mb-3">Jelajahi Dunia Tanpa Batas</h1>
        <p class="lead mb-4 fw-light">Temukan tiket wisata, event populer, dan transportasi dengan harga terbaik dan pengalaman tak terlupakan di TravelKu.</p>
        <a href="#explore" class="btn btn-primary btn-lg fw-bold rounded-pill px-5 py-3 shadow-sm">
            Mulai Petualangan <i class="bi bi-arrow-down-circle ms-2"></i>
        </a>
    </div>
</div>

<!-- Keunggulan Section (Why Choose Us) -->
<div class="container mb-5">
    <div class="row g-4 text-center">
        <div class="col-md-4">
            <div class="card border-0 bg-transparent">
                <div class="feature-icon-box mb-3 shadow-sm">
                    <i class="bi bi-tag-fill fs-2"></i>
                </div>
                <h5 class="fw-bold">Harga Terbaik</h5>
                <p class="text-muted small">Nikmati berbagai promo dan diskon spesial untuk setiap pemesanan tiket Anda.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 bg-transparent">
                <div class="feature-icon-box mb-3 shadow-sm">
                    <i class="bi bi-shield-check fs-2"></i>
                </div>
                <h5 class="fw-bold">Transaksi Aman</h5>
                <p class="text-muted small">Sistem pembayaran terenkripsi untuk menjamin keamanan privasi dan data Anda.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 bg-transparent">
                <div class="feature-icon-box mb-3 shadow-sm">
                    <i class="bi bi-lightning-charge-fill fs-2"></i>
                </div>
                <h5 class="fw-bold">E-Tiket Instan</h5>
                <p class="text-muted small">Tiket langsung terbit setelah pembayaran sukses, tanpa perlu antre cetak fisik.</p>
            </div>
        </div>
    </div>
</div>

<!-- Main Content: Wisata & Event Pilihan -->
<div class="container mb-5" id="explore">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-0"><i class="bi bi-compass-fill text-primary me-2"></i>Rekomendasi Destinasi</h3>
            <p class="text-muted small m-0 mt-1">Pilihan wisata dan event terbaik minggu ini</p>
        </div>
        <a href="#" class="btn btn-outline-primary btn-sm rounded-pill px-3">Lihat Semua</a>
    </div>

    <div class="row g-4">
        <?php if (mysqli_num_rows($events) > 0): ?>
            <?php while ($e = mysqli_fetch_assoc($events)): ?>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100 modern-card">
                    <div class="position-relative">
                        <?php if (!empty($e['gambar'])): ?>
                            <img src="uploads/<?= $e['gambar']; ?>" class="card-img-top w-100" alt="<?= htmlspecialchars($e['nama_event']); ?>" style="height: 220px; object-fit: cover;">
                        <?php else: ?>
                            <div class="bg-secondary text-white d-flex align-items-center justify-content-center" style="height: 220px; border-top-left-radius: 1rem; border-top-right-radius: 1rem;">
                                <i class="bi bi-image fs-1 opacity-50"></i>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Badge Kategori Mengambang -->
                        <div class="position-absolute top-0 start-0 m-3">
                            <span class="badge bg-light text-primary fw-bold shadow-sm px-3 py-2 rounded-pill">
                                <?= ucfirst($e['kategori']); ?>
                            </span>
                        </div>
                    </div>

                    <div class="card-body p-4 d-flex flex-column justify-content-between">
                        <div>
                            <p class="text-muted small mb-2">
                                <i class="bi bi-calendar-event text-primary"></i> <?= !empty($e['tanggal']) ? date('d M Y', strtotime($e['tanggal'])) : 'Berlaku Kapan Saja'; ?>
                            </p>
                            <h5 class="fw-bold text-dark mb-2"><?= htmlspecialchars($e['nama_event']); ?></h5>
                            <p class="text-muted small mb-3">
                                <i class="bi bi-geo-alt-fill text-danger"></i> <?= htmlspecialchars($e['lokasi']); ?>
                            </p>
                            <!-- Membatasi teks deskripsi 2 baris (butuh class line-clamp, atau di trim php) -->
                            <p class="card-text text-secondary small" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                                <?= htmlspecialchars($e['deskripsi']); ?>
                            </p>
                        </div>

                        <div class="border-top pt-3 mt-3 d-flex justify-content-between align-items-center">
                            <div>
                                <small class="text-muted d-block" style="font-size: 0.8rem;">Mulai dari</small>
                                <span class="fw-bolder text-primary fs-5">Rp <?= number_format($e['harga'], 0, ',', '.'); ?></span>
                            </div>
                            <a href="checkout.php?id=<?= $e['id']; ?>&type=event" class="btn btn-primary rounded-pill px-4 fw-semibold">
                                Pesan
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <div class="p-5 bg-white rounded-4 shadow-sm border-0">
                    <i class="bi bi-ticket-detailed fs-1 text-muted d-block mb-3"></i>
                    <h5 class="fw-bold">Belum Ada Tiket Tersedia</h5>
                    <p class="text-muted">Coba kembali lagi nanti untuk melihat wisata atau event terbaru.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Promo CTA Section -->
<div class="container mb-5">
    <div class="cta-section text-white p-5 shadow">
        <div class="row align-items-center text-center text-md-start">
            <div class="col-md-8 mb-4 mb-md-0">
                <h2 class="fw-bold mb-2">Ingin Liburan Lebih Hemat?</h2>
                <p class="lead opacity-75 mb-0">Cek halaman promo sekarang dan dapatkan potongan harga eksklusif untuk tiket transportasi dan wisata Anda.</p>
            </div>
            <div class="col-md-4 text-md-end">
                <a href="promo.php" class="btn btn-light text-primary btn-lg fw-bold rounded-pill shadow-sm px-4">
                    <i class="bi bi-tags-fill me-2"></i> Cek Promo Sekarang
                </a>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>