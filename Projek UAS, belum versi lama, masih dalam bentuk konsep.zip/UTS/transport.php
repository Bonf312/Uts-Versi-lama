<?php
require_once __DIR__ . '/config/database.php';
include 'header.php';

// Ambil data transportasi
$transports = mysqli_query($conn, "SELECT * FROM transports ORDER BY id DESC");
?>

<div class="hero-banner text-center mb-5 bg-success">
    <div class="container">
        <h1 class="fw-bold display-5">Tiket Transportasi Lengkap</h1>
        <p class="lead opacity-75">Pesan tiket Bus, Kereta Api, dan Pesawat untuk perjalanan impianmu</p>
    </div>
</div>

<div class="container mb-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold"><i class="bi bi-bus-front-fill text-success"></i> Jadwal Keberangkatan Transportasi</h3>
    </div>

    <div class="row g-4">
        <?php if (mysqli_num_rows($transports) > 0): ?>
            <?php while ($t = mysqli_fetch_assoc($transports)): ?>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm p-4 card-hover">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="badge bg-secondary uppercase"><?= strtoupper($t['jenis']); ?></span>
                        <span class="text-muted small"><i class="bi bi-clock"></i> <?= date('d M Y, H:i', strtotime($t['waktu_berangkat'])); ?> WIB</span>
                    </div>

                    <h4 class="fw-bold text-success mb-3"><?= htmlspecialchars($t['nama_armada']); ?></h4>

                    <div class="row align-items-center mb-3 bg-light p-3 rounded">
                        <div class="col-5 text-center">
                            <small class="text-muted d-block">Kota Asal</small>
                            <strong class="fs-6"><?= htmlspecialchars($t['asal']); ?></strong>
                        </div>
                        <div class="col-2 text-center text-success">
                            <i class="bi bi-arrow-right fs-4"></i>
                        </div>
                        <div class="col-5 text-center">
                            <small class="text-muted d-block">Kota Tujuan</small>
                            <strong class="fs-6"><?= htmlspecialchars($t['tujuan']); ?></strong>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center border-top pt-3">
                        <div>
                            <small class="text-muted d-block">Sisa Kursi: <strong><?= $t['stok_kursi']; ?></strong></small>
                            <span class="fw-bold text-success fs-5">Rp <?= number_format($t['harga'], 0, ',', '.'); ?></span>
                        </div>
                        <!-- Arahkan ke file checkout yang kamu miliki -->
                        <a href="checkout.php?id=<?= $t['id']; ?>&type=transport" class="btn btn-success fw-bold">
                            <i class="bi bi-check-circle"></i> Pilih Tiket
                        </a>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted">Belum ada rute transportasi yang tersedia.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer.php'; ?>